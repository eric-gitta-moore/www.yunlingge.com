<?php

/**
 * data
 * @author auto create
 */
class MapData
{
	
	/** 
	 * password
	 **/
	public $model;	
}
//WWW.CAOGEN8.CO
?>