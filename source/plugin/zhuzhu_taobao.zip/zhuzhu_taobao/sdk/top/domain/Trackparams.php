<?php

/**
 * 埋点信息
 * @author auto create
 */
class Trackparams
{
	
	/** 
	 * empty
	 **/
	public $empty;	
}
//WWW.CAOGEN8.CO
?>