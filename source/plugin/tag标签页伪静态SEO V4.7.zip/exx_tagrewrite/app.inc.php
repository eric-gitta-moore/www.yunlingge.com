<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (! defined ('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}
echo "<script language='javascript'>";
echo "window.location.href='https://dism.taobao.com/?@68502.developer'";
echo "</script>";
exit;