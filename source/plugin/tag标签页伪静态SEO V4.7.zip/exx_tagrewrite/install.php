<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/exx_tagrewrite/discuz_plugin_exx_tagrewrite.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_tagrewrite/discuz_plugin_exx_tagrewrite_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_tagrewrite/discuz_plugin_exx_tagrewrite_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_tagrewrite/discuz_plugin_exx_tagrewrite_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/exx_tagrewrite/discuz_plugin_exx_tagrewrite_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/exx_tagrewrite/install.php');