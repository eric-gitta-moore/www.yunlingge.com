<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc && plugin by zhanmishu.
 *      Dz����www.idzbox.com, use is subject to license terms
 *
 *      Author: zhanmishu.com $
 *      qq:87883395 $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
  exit('Access Denied');
}

//  $sql = <<<EOF

// EOF;
//runquery($sql);

$finish = TRUE;


?>