<?php

require_once DISCUZ_ROOT.'./source/plugin/bineoo_storage/OSS/Model/CnameConfig.php';

class GetCnameResult extends Result
{
    /**
     * @return CnameConfig
     */
    protected function parseDataFromResponse()
    {
        $content = $this->rawResponse->body;
        $config = new CnameConfig();
        $config->parseFromXml($content);
        return $config;
    }
}