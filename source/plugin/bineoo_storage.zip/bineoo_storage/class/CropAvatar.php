<?php
/**
 *  Version: 1.0
 *  Date: 2017-03-25 15:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class CropAvatar {
	private $src;
	private $data;
	private $dst;
	private $type;
	private $extension;
	private $msg;
	private $uid;
	private $original;

	function __construct($data, $file, $uid, $oss) {
		global $_G;
		$this->uid = $uid;
		$this->setSrc();
		$this->setData($data);
		$this->setFile($file);
		$this->crop($this->src, $this->dst, $this->data);
		if(is_file($this->getResult())){
			@unlink($this->original);
			if($oss){
				list($ossClient,$oss_set) = oss_client();
				$big = $this->getResult();
				$middle_tmp = 'temp/'.md5($this->uid).'_middle.jpg';
				$small_tmp = 'temp/'.md5($this->uid).'_small.jpg';
				require_once libfile('class/image');
				$image = new image();
				if($image->Thumb($big, $middle_tmp, 120, 120, 1)){
					$ossClient->multiuploadFile($oss_set['bucket'], 'uc_server/data/avatar/'.$this->get_avatar($this->uid,'middle'), 'data/attachment/'.$middle_tmp);
					@unlink('data/attachment/'.$middle_tmp);
				}
				if($image->Thumb($big, 'temp/'.md5($this->uid).'_small.jpg', 48, 48, 1)){
					$ossClient->multiuploadFile($oss_set['bucket'], 'uc_server/data/avatar/'.$this->get_avatar($this->uid,'small'), 'data/attachment/'.$small_tmp);
					@unlink('data/attachment/'.$small_tmp);
				}

				$ossClient->multiuploadFile($oss_set['bucket'], 'uc_server/data/avatar/'.$this->get_avatar($this->uid,'big'), $big);
				@unlink($big);
			}
		}
	}

	private function setSrc($src) {
		if (!empty($src)) {
			$type = exif_imagetype($src);

			if ($type) {
				$this->src = $src;
				$this->type = $type;
				$this->extension = image_type_to_extension($type);
				$this->setDst();
			}
		}
	}

	private function setData($data) {
		if (!empty($data)) {
			$this->data = json_decode(stripslashes($data));
		}
	}

	private function setFile($file) {
		$errorCode = $file['error'];
		if ($errorCode === UPLOAD_ERR_OK) {
			$type = exif_imagetype($file['tmp_name']);

			if ($type) {
				$extension = image_type_to_extension($type);
				$this->original = $src = 'data/attachment/temp/'.md5(date('YmdHis')).'.original'.$extension;

				if ($type == IMAGETYPE_GIF || $type == IMAGETYPE_JPEG || $type == IMAGETYPE_PNG) {

					if (file_exists($src)) {
						unlink($src);
					}

					$result = move_uploaded_file($file['tmp_name'], $src);

					if ($result) {
						$this->src = $src;
						$this->type = $type;
						$this->extension = $extension;
						$this->setDst();
					} else {
						$this->msg = 'Failed to save file';
					}
				} else {
					$this->msg = 'Please upload image with the following types: JPG, PNG, GIF';
				}
			} else {
				$this->msg = 'Please upload image file';
			}
		} else {
			$this->msg = $this->codeToMessage($errorCode);
		}
	}

	private function setDst() {
		$this->dst = 'data/attachment/temp/'.md5($this->uid).'_big.jpg';
	}

	private function crop($src, $dst, $data) {
		if (!empty($src) && !empty($dst) && !empty($data)) {
			switch ($this->type) {
				case IMAGETYPE_GIF:
					$src_img = imagecreatefromgif($src);
					break;

				case IMAGETYPE_JPEG:
					$src_img = imagecreatefromjpeg($src);
					break;

				case IMAGETYPE_PNG:
					$src_img = imagecreatefrompng($src);
					break;
			}

			if (!$src_img) {
				$this->msg = "Failed to read the image file";
				return;
			}

			$size = getimagesize($src);
			$size_w = $size[0]; // natural width
			$size_h = $size[1]; // natural height

			$src_img_w = $size_w;
			$src_img_h = $size_h;

			$degrees = $data -> rotate;

			// Rotate the source image
			if (is_numeric($degrees) && $degrees != 0) {
				$new_img = imagerotate( $src_img, -$degrees, imagecolorallocatealpha($src_img, 0, 0, 0, 127) );

				imagedestroy($src_img);
				$src_img = $new_img;

				$deg = abs($degrees) % 180;
				$arc = ($deg > 90 ? (180 - $deg) : $deg) * M_PI / 180;

				$src_img_w = $size_w * cos($arc) + $size_h * sin($arc);
				$src_img_h = $size_w * sin($arc) + $size_h * cos($arc);
				$src_img_w -= 1;
				$src_img_h -= 1;
			}

			$tmp_img_w = $data -> width;
			$tmp_img_h = $data -> height;
			$dst_img_w = 220;
			$dst_img_h = 220;

			$src_x = $data -> x;
			$src_y = $data -> y;

			if ($src_x <= -$tmp_img_w || $src_x > $src_img_w) {
				$src_x = $src_w = $dst_x = $dst_w = 0;
			} else if ($src_x <= 0) {
				$dst_x = -$src_x;
				$src_x = 0;
				$src_w = $dst_w = min($src_img_w, $tmp_img_w + $src_x);
			} else if ($src_x <= $src_img_w) {
				$dst_x = 0;
				$src_w = $dst_w = min($tmp_img_w, $src_img_w - $src_x);
			}

			if ($src_w <= 0 || $src_y <= -$tmp_img_h || $src_y > $src_img_h) {
				$src_y = $src_h = $dst_y = $dst_h = 0;
			} else if ($src_y <= 0) {
				$dst_y = -$src_y;
				$src_y = 0;
				$src_h = $dst_h = min($src_img_h, $tmp_img_h + $src_y);
			} else if ($src_y <= $src_img_h) {
				$dst_y = 0;
				$src_h = $dst_h = min($tmp_img_h, $src_img_h - $src_y);
			}

			// Scale to destination position and size
			$ratio = $tmp_img_w / $dst_img_w;
			$dst_x /= $ratio;
			$dst_y /= $ratio;
			$dst_w /= $ratio;
			$dst_h /= $ratio;

			$dst_img = imagecreatetruecolor($dst_img_w, $dst_img_h);

			// Add transparent background to destination image
			imagefill($dst_img, 0, 0, imagecolorallocatealpha($dst_img, 0, 0, 0, 127));
			imagesavealpha($dst_img, true);

			$result = imagecopyresampled($dst_img, $src_img, $dst_x, $dst_y, $src_x, $src_y, $dst_w, $dst_h, $src_w, $src_h);

			if ($result) {
				if (!imagepng($dst_img, $dst)) {
					$this->msg = "Failed to save the cropped image file";
				}
			} else {
				$this->msg = "Failed to crop the image file";
			}

			imagedestroy($src_img);
			imagedestroy($dst_img);
		}
	}

	private function codeToMessage($code) {
		$errors = array(
			UPLOAD_ERR_INI_SIZE =>'The uploaded file exceeds the upload_max_filesize directive in php.ini',
			UPLOAD_ERR_FORM_SIZE =>'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form',
			UPLOAD_ERR_PARTIAL =>'The uploaded file was only partially uploaded',
			UPLOAD_ERR_NO_FILE =>'No file was uploaded',
			UPLOAD_ERR_NO_TMP_DIR =>'Missing a temporary folder',
			UPLOAD_ERR_CANT_WRITE =>'Failed to write file to disk',
			UPLOAD_ERR_EXTENSION =>'File upload stopped by extension',
		);

		if (array_key_exists($code, $errors)) {
			return $errors[$code];
		}

		return 'Unknown upload error';
	}

	public function getResult() {
		return !empty($this->data) ? $this->dst : $this->src;
	}

	public function getMsg() {
		return $this->msg;
	}

	private function get_home($uid) {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		return $dir1.'/'.$dir2.'/'.$dir3;
	}

	private function get_avatar($uid,$size, $type = '') {
		$size = in_array($size, array('big', 'middle', 'small')) ? $size : 'big';
		$uid = abs(intval($uid));
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$typeadd = $type == 'real' ? '_real' : '';
		return  $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).$typeadd."_avatar_$size.jpg";
	}
}