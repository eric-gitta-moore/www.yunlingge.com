<style></style>
				<script>
				function comiis_app_portal_loop(h, speed, delay, sid) {
					var t = null;
					var o = document.getElementById(sid);
					o.innerHTML += o.innerHTML;
					o.scrollTop = 0;
					function start() {
						t = setInterval(scrolling, speed);
						o.scrollTop += 2;
					}
					function scrolling() {
						if(o.scrollTop % h != 0) {
							o.scrollTop += 2;
							if(o.scrollTop >= o.scrollHeight / 2) o.scrollTop = 0;
						} else {
							clearInterval(t);
							setTimeout(start, delay);
						}
					}
					setTimeout(start, delay);
				}
				function comiis_app_portal_swiper(a, b){
					if(typeof(Swiper) == 'undefined') {
						$.getScript("./source/plugin/comiis_app_portal/image/comiis.js").done(function(){
							new Swiper(a, b);
						});
					}else{
						new Swiper(a, b);
					}
				}
				</script><div id="comiis_app_block_4" class="bg_f mt10 b_t b_b cl"><div class="comiis_mh_txtlist cl">
<ul>
    <li class="b_t"><a href="forum.php?mod=viewthread&tid=140" title="0000000"><span class="f_d y">02-11</span><font class="f_0">[娱乐八卦]</font> 0000000</a></li>
<li class="b_t"><a href="forum.php?mod=viewthread&tid=139" title="测试抢楼主题"><span class="f_d y">02-11</span><font class="f_0">[默认版块]</font> 测试抢楼主题</a></li>
<li class="b_t"><a href="forum.php?mod=viewthread&tid=138" title="22222222222"><span class="f_d y">02-10</span><font class="f_0">[默认版块]</font> 22222222222</a></li>
<li class="b_t"><a href="forum.php?mod=viewthread&tid=137" title="0000000000"><span class="f_d y">02-10</span><font class="f_0">[默认版块]</font> 0000000000</a></li>
<li class="b_t"><a href="forum.php?mod=viewthread&tid=136" title="0000000000000"><span class="f_d y">02-08</span><font class="f_0">[分类1]</font> 0000000000000</a></li>
</ul>
</div>
</div><div id="comiis_app_block_1" class="bg_f mt10 b_t b_b cl"><div class="comiis_mhswf comiis_mhswf1">
<ul class="swiper-wrapper">
    <li class="swiper-slide">
      <a href="forum.php?mod=viewthread&tid=119" title="000000000">
<img src="./template/comiis_app/pic/none.png" comiis_loadimages="data/attachment/forum/201801/22/132503k54cjcizkct5cy5i.jpg" width="100%" class="vm comiis_mhswf_whb1 comiis_loadimages" alt="000000000">
<span>000000000</span>
</a>
</li>
<li class="swiper-slide">
      <a href="forum.php?mod=viewthread&tid=131" title="再来一张2张图">
<img src="./template/comiis_app/pic/none.png" comiis_loadimages="data/attachment/forum/201802/06/190140byybbjg0ggybgadr.jpg" width="100%" class="vm comiis_mhswf_whb1 comiis_loadimages" alt="再来一张2张图">
<span>再来一张2张图</span>
</a>
</li>
<li class="swiper-slide">
      <a href="forum.php?mod=viewthread&tid=118" title="[江宁]">
<img src="./template/comiis_app/pic/none.png" comiis_loadimages="data/attachment/forum/201801/17/143523njyxw4m7sxjtqm4q.jpg" width="100%" class="vm comiis_mhswf_whb1 comiis_loadimages" alt="[江宁]">
<span>[江宁]</span>
</a>
</li>
<li class="swiper-slide">
      <a href="forum.php?mod=viewthread&tid=97" title="再次测试上传图片后压缩">
<img src="./template/comiis_app/pic/none.png" comiis_loadimages="data/attachment/forum/201712/29/111649jh1iky30555ish1x.jpg" width="100%" class="vm comiis_mhswf_whb1 comiis_loadimages" alt="再次测试上传图片后压缩">
<span>再次测试上传图片后压缩</span>
</a>
</li>
<li class="swiper-slide">
      <a href="forum.php?mod=viewthread&tid=128" title="000000000">
<img src="./template/comiis_app/pic/none.png" comiis_loadimages="data/attachment/forum/201802/03/161927r3bvd2ijs284vz3n.jpg" width="100%" class="vm comiis_mhswf_whb1 comiis_loadimages" alt="000000000">
<span>000000000</span>
</a>
</li>
</ul>
<div class="comiis_mhswf_roll comiis_mhswf_roll1"></div>
</div>
<script>
  $('.comiis_mhswf_whb1').css('height', ($('.comiis_mhswf_whb1').width() * 0.56) + 'px');
comiis_app_portal_swiper('.comiis_mhswf1', {
slidesPerView : 'auto',
        pagination: '.comiis_mhswf_roll1',
        paginationType: 'fraction',
loop: true,
autoplay: 5000,
        autoplayDisableOnInteraction: false,
onTouchMove: function(swiper){
Comiis_Touch_on = 0;
},
onTouchEnd: function(swiper){
Comiis_Touch_on = 1;
},
});
</script>
</div> <div id="comiis_app_block_2" class="bg_f mt10 b_t b_b cl"><div class="comiis_mh_toutiao b_b cl">
<ul>	
<li>
<a href="forum.php?mod=viewthread&tid=119">
<span class="hottit f_g">000000000</span>
<span class="f_c">...</span>
</a>
</li>
</ul>
</div>
</div><div id="comiis_app_block_3" class="bg_f mt10 b_t b_b cl"><div class="comiis_mh_gz03 cl"><a href="#" class="b_r b_b"><img src="source/plugin/comiis_app_portal/image/001.png" class="vm"><h2 style="color:#FF9900">今日热点</h2><span class="f_c">每日精选播报</span></a><a href="#" class="b_b"><img src="source/plugin/comiis_app_portal/image/002.png" class="vm"><h2 style="color:#87D140">福利活动</h2><span class="f_c">最多的优惠福利</span></a><a href="#" class="b_r b_b"><img src="source/plugin/comiis_app_portal/image/003.png" class="vm"><h2 style="color:#20b4ff">每日签到</h2><span class="f_c">天天签到财神到</span></a><a href="#" class="b_b"><img src="source/plugin/comiis_app_portal/image/004.png" class="vm"><h2 style="color:#FF5F45">品牌商家</h2><span class="f_c">星级商家保证</span></a></div></div>